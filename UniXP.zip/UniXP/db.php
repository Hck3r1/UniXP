<?php
$conn = new mysqli("localhost", "wetinde2_hck3rr", "feranmi2645", "wetinde2_hck3rrdb");
if (mysqli_connect_errno()){
    printf("connect failed: %s\n", mysqli_connect_error());
    exit();
}
?>